package com.stackoverflow.services.answer;


import com.stackoverflow.dtos.AnswerDto;

public interface AnswerService{
    AnswerDto postAnswer(AnswerDto answerDto);
}
