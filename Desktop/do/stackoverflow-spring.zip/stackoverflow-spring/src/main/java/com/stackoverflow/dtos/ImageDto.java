package com.stackoverflow.dtos;

import lombok.Data;

@Data
public class ImageDto {
   String[] image;
}
