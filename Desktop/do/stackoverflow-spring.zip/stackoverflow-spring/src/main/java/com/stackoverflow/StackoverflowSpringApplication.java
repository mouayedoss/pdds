package com.stackoverflow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StackoverflowSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(StackoverflowSpringApplication.class, args);
	}

}
