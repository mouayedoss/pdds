package com.stackoverflow.enums;

public enum VoteType {
    DOWNVOTE(-1),

    UPVOTE(+1);

    VoteType(int direction) {
    }
}
